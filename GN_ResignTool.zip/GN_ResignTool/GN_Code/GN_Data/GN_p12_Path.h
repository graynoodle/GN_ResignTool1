//
//  GN_Get_p12_Path.h
//  DragAndDrop
//
//  Created by chenghxc on 13-2-25.
//  Copyright (c) 2013年 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface GN_Get_p12_Path : NSView
@end