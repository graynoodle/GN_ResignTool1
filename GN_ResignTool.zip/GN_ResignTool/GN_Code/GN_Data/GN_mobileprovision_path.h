
#import <Cocoa/Cocoa.h>

@interface GN_mobileprovision_path : NSView
@end